(function () {
    const storageKey = "think-mart-cart";
    const formatPrice = (amount) => new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0
    }).format(amount);

    function readCart() {
        try {
            const cart = JSON.parse(localStorage.getItem(storageKey) || "[]");
            return Array.isArray(cart) ? cart : [];
        } catch {
            return [];
        }
    }

    function saveCart(cart) {
        localStorage.setItem(storageKey, JSON.stringify(cart));
        renderCart();
    }

    function renderCart() {
        const cart = readCart();
        const itemCount = cart.reduce((count, item) => count + item.quantity, 0);
        document.querySelectorAll("[data-cart-count]").forEach((badge) => {
            badge.textContent = itemCount;
        });

        const itemList = document.querySelector("[data-cart-items]");
        if (!itemList) return;

        const itemCountLabel = document.querySelector("[data-cart-item-count]");
        const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
        const delivery = subtotal === 0 || subtotal >= 10000 ? 0 : 499;
        itemCountLabel.textContent = `(${itemCount})`;
        document.querySelector("[data-cart-subtotal]").textContent = formatPrice(subtotal);
        document.querySelector("[data-cart-delivery]").textContent = delivery === 0 && subtotal > 0 ? "Free" : formatPrice(delivery);
        document.querySelector("[data-cart-total]").textContent = formatPrice(subtotal + delivery);
        document.querySelector("[data-delivery-note]").textContent = subtotal === 0
            ? "Shipping is calculated at checkout."
            : delivery === 0
                ? "Your order qualifies for free delivery."
                : `Add ${formatPrice(10000 - subtotal)} more for free delivery.`;
        document.querySelector("[data-checkout]").disabled = cart.length === 0;
        itemList.replaceChildren();

        if (cart.length === 0) {
            const empty = document.createElement("div");
            empty.className = "empty-cart";
            empty.innerHTML = '<span aria-hidden="true">◎</span><h3>Your cart is taking a breather.</h3><p>Find something you love and it will show up here.</p><a class="button button-dark" href="Products.html">Explore products</a>';
            itemList.append(empty);
            return;
        }

        cart.forEach((item) => {
            const row = document.createElement("article");
            row.className = "cart-item";
            const image = document.createElement("img");
            image.src = item.image;
            image.alt = item.name;
            const details = document.createElement("div");
            details.className = "cart-item-details";
            const name = document.createElement("h3");
            name.textContent = item.name;
            const unitPrice = document.createElement("p");
            unitPrice.textContent = `${formatPrice(item.price)} each`;
            const quantity = document.createElement("label");
            quantity.className = "quantity-control";
            quantity.append("Qty ");
            const input = document.createElement("input");
            input.type = "number";
            input.min = "1";
            input.max = "99";
            input.value = item.quantity;
            input.setAttribute("aria-label", `Quantity for ${item.name}`);
            input.addEventListener("change", () => {
                const updated = readCart();
                const match = updated.find((entry) => entry.id === item.id);
                if (match) match.quantity = Math.min(99, Math.max(1, Number(input.value) || 1));
                saveCart(updated);
            });
            quantity.append(input);
            const remove = document.createElement("button");
            remove.className = "remove-item";
            remove.type = "button";
            remove.textContent = "Remove";
            remove.addEventListener("click", () => saveCart(readCart().filter((entry) => entry.id !== item.id)));
            details.append(name, unitPrice, quantity, remove);
            const lineTotal = document.createElement("strong");
            lineTotal.className = "cart-line-total";
            lineTotal.textContent = formatPrice(item.price * item.quantity);
            row.append(image, details, lineTotal);
            itemList.append(row);
        });
    }

    document.querySelectorAll(".add-to-cart").forEach((button) => {
        button.addEventListener("click", () => {
            const product = button.closest("[data-product-id]");
            const cart = readCart();
            const existing = cart.find((item) => item.id === product.dataset.productId);
            if (existing) existing.quantity = Math.min(99, existing.quantity + 1);
            else cart.push({
                id: product.dataset.productId,
                name: product.dataset.name,
                price: Number(product.dataset.price),
                image: product.dataset.image,
                quantity: 1
            });
            saveCart(cart);
            const originalText = button.textContent;
            button.textContent = "Added";
            window.setTimeout(() => { button.textContent = originalText; }, 1100);
        });
    });

    document.querySelector("[data-checkout]")?.addEventListener("click", () => {
        window.alert("Thanks for shopping with Think Mart! Checkout is coming soon.");
    });

    renderCart();
})();